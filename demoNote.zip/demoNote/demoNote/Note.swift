//
//  Note.swift
//  demoNote
//
//  Created by Kien on 4/20/16.
//  Copyright © 2016 Kienpham. All rights reserved.
//

import UIKit
var allNote:[Note] = []
var Noteindexpath:Int = -1
var NoteTable:UITableView?
let kallNote:String="notes"
class Note: NSObject {
    var date:String = ""
    var note:String = ""
    override init() {
        date=NSDate().description
        note=""
    }
    func dictory() -> NSDictionary {
        return ["note":note,"date":date]
    }
    class func saveNote()
    {
        var dictoryall:[NSDictionary]=[]
        for var i:Int=0;i<allNote.count; i++
        {
            dictoryall.append(allNote[i].dictory())
        }
        NSUserDefaults.standardUserDefaults().setObject(dictoryall, forKey: kallNote)
    }
    class func loadNote()
    {
        
        var defaul:NSUserDefaults=NSUserDefaults.standardUserDefaults()
        var saveData:[NSDictionary]?=defaul.objectForKey(kallNote) as? [NSDictionary]
        if let data:[NSDictionary]=saveData{
          for  var i:Int=0;i < data.count;i++
            
          {
            var n:Note=Note()
            n.setValuesForKeysWithDictionary(data[i] as! [String : AnyObject])
            allNote.append(n)
            
            }
}
}
}